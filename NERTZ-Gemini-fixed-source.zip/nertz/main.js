'use strict';
const { app, BrowserWindow, ipcMain, shell, safeStorage, session, dialog, Menu } = require('electron');
const path = require('path'), fs = require('fs'), { spawn } = require('child_process');

if (!app.requestSingleInstanceLock()) app.quit();
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

let win;
const P = f => path.join(app.getPath('userData'), f);
const log = m => { try { fs.mkdirSync(app.getPath('userData'), { recursive: true }); fs.appendFileSync(P('nertz.log'), new Date().toISOString() + ' ' + m + '\n'); } catch {} };
/* Compatibility mode = software rendering. Default on 32-bit systems; also switched on automatically after a GPU crash. */
if (process.arch === 'ia32' || fs.existsSync(P('nogpu'))) app.disableHardwareAcceleration();
const compatRestart = () => { try { fs.writeFileSync(P('nogpu'), '1'); } catch {} app.relaunch(); app.exit(0); };
const rd = (f, d) => { try { return JSON.parse(fs.readFileSync(P(f), 'utf8')); } catch { return d; } };
const wr = (f, v) => { fs.mkdirSync(app.getPath('userData'), { recursive: true }); fs.writeFileSync(P(f), JSON.stringify(v)); };

const DEF = { provider: 'gemini', model: '', searchProvider: 'tavily', voice: '', voiceVolume: 1,
  startupSound: true, startupVolume: 0.6, reducedMotion: false, intensity: 1, mic: '', memoryOn: true, userName: 'sir' };
const settings = () => ({ ...DEF, ...rd('settings.json', {}), provider: 'gemini', baseUrl: '' });

/* ---- secrets: encrypted with Windows DPAPI via safeStorage, never sent to the UI ---- */
function keys() {
  try { return fs.existsSync(P('keys.bin')) ? JSON.parse(safeStorage.decryptString(fs.readFileSync(P('keys.bin')))) : {}; }
  catch { return {}; }
}
function saveKeys(k) {
  if (!safeStorage.isEncryptionAvailable()) throw new Error('Secure key storage is not available on this system.');
  fs.mkdirSync(app.getPath('userData'), { recursive: true });
  fs.writeFileSync(P('keys.bin'), safeStorage.encryptString(JSON.stringify(k)));
}

/* ---- helpers ---- */
async function http(url, opt = {}, ms = 60000) {
  let r;
  try { r = await fetch(url, { ...opt, signal: AbortSignal.timeout(ms) }); }
  catch (e) { throw new Error(e.name === 'TimeoutError' ? 'The request timed out.' : 'Could not reach the service. Check the internet connection.'); }
  if (!r.ok) {
    let t = ''; try { const body = await r.json(); t = body.error?.message || JSON.stringify(body).slice(0, 240); } catch {}
    throw new Error(r.status === 400 || r.status === 401 || r.status === 403
      ? `Gemini rejected the request (${r.status}): ${t || 'Check the API key and Gemini API access.'}`
      : r.status === 429 ? `Gemini quota or rate limit reached (429): ${t || 'Check your AI Studio quota.'}`
      : `Gemini service error ${r.status}: ${t}`);
  }
  return r;
}
const h = (ch, fn) => ipcMain.handle(ch, async (_e, a) => {
  try { return { ok: true, ...(await fn(a || {})) }; } catch (err) { return { ok: false, error: err.message || String(err) }; }
});
const geminiModel = st => String(st.model || 'gemini-2.5-flash').trim().replace(/^models\//, '');
const geminiUrl = (model, key, action = '') => `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}${action}?key=${encodeURIComponent(key)}`;

async function validateAi(_prov, key, st) {
  const r = await http(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(key)}`, {}, 15000);
  const data = await r.json();
  const models = data.models || [];
  if (models.length && !models.some(m => (m.supportedGenerationMethods || []).includes('generateContent'))) {
    throw new Error('The key is accepted, but this API project has no models available for generateContent. Check Gemini API access in Google AI Studio.');
  }
  return true;
}
async function runSearch(prov, key, q) {
  if (prov === 'brave') {
    const r = await http('https://api.search.brave.com/res/v1/web/search?count=8&q=' + encodeURIComponent(q), { headers: { 'X-Subscription-Token': key, Accept: 'application/json' } }, 20000);
    const j = await r.json();
    return (j.web?.results || []).map(x => ({ title: x.title, url: x.url, snippet: (x.description || '').replace(/<[^>]+>/g, ''), date: x.age || '' }));
  }
  const r = await http('https://api.tavily.com/search', { method: 'POST', headers: { 'content-type': 'application/json', Authorization: 'Bearer ' + key },
    body: JSON.stringify({ query: q, max_results: 8 }) }, 25000);
  const j = await r.json();
  return (j.results || []).map(x => ({ title: x.title, url: x.url, snippet: x.content || '', date: x.published_date || '' }));
}

/* ---- IPC ---- */
h('settings:get', async () => ({ settings: settings(), hasAiKey: !!keys().ai, hasSearchKey: !!keys().search }));
h('settings:set', async p => { const next = { ...settings(), ...p, provider: 'gemini' }; delete next.baseUrl; wr('settings.json', next); return {}; });
h('key:save', async ({ kind, value }) => {
  value = String(value || '').trim(); if (!value) throw new Error('Paste a key first.');
  const st = settings(), k = keys();
  if (kind === 'ai') {
    await validateAi('gemini', value, st); k.ai = value; saveKeys(k);
    wr('settings.json', { ...st, provider: 'gemini', baseUrl: '' });
    return { provider: 'gemini' };
  }
  await runSearch(st.searchProvider, value, 'test'); k.search = value; saveKeys(k); return {};
});
h('key:clear', async ({ kind }) => { const k = keys(); delete k[kind === 'ai' ? 'ai' : 'search']; saveKeys(k); return {}; });
h('status', async () => {
  let internet = false;
  try { await fetch('https://www.gstatic.com/generate_204', { signal: AbortSignal.timeout(4000) }); internet = true; } catch {}
  const st = settings(), k = keys();
  return { internet, local: false, aiConfigured: !!k.ai,
    searchConfigured: st.searchProvider !== 'none' && !!k.search };
});
h('ai:chat', async ({ system, messages }) => {
  const st = settings(), k = keys().ai || '';
  if (!k) throw new Error('No Gemini API key is saved. Open Settings and add your Google AI Studio key.');
  const contents = (messages || []).map(m => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [
      ...(m.images || []).map(d => { const p = /^data:([^;]+);base64,(.+)$/.exec(d); if (!p) throw new Error('An attached image has an invalid data format.'); return { inline_data: { mime_type: p[1], data: p[2] } }; }),
      { text: String(m.content || ' ') }
    ]
  }));
  const body = { contents, generationConfig: { maxOutputTokens: 4096 } };
  if (system) body.systemInstruction = { parts: [{ text: String(system) }] };
  const r = await http(geminiUrl(geminiModel(st), k, ':generateContent'), {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body)
  }, 120000);
  const data = await r.json();
  const text = (data.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('');
  if (!text) throw new Error(data.promptFeedback?.blockReason ? `Gemini blocked this request: ${data.promptFeedback.blockReason}.` : 'Gemini returned an empty response. Try another model or a different prompt.');
  return { text };
});
h('search:web', async ({ q }) => {
  const st = settings(), k = keys().search;
  if (st.searchProvider === 'none' || !k) throw new Error('Web search is not configured.');
  return { results: await runSearch(st.searchProvider, k, q) };
});
h('stt', async ({ b64, mime }) => {
  const st = settings(), k = keys().ai || '';
  if (!k) throw new Error('Add your Gemini API key in Settings before using voice input.');
  if (!b64) throw new Error('No microphone audio was received.');
  const r = await http(geminiUrl(geminiModel(st), k, ':generateContent'), {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ contents: [{ role: 'user', parts: [
      { inline_data: { mime_type: mime || 'audio/webm', data: b64 } },
      { text: 'Transcribe the spoken words exactly. Return only the transcription, with no explanation.' }
    ] }], generationConfig: { maxOutputTokens: 1024 } })
  }, 60000);
  const data = await r.json();
  return { text: (data.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('').trim() };
});
h('ext:open', async ({ url }) => {
  const u = new URL(url); if (!/^https?:$/.test(u.protocol)) throw new Error('Only web links can be opened.');
  await shell.openExternal(u.href); return {};
});
const APPS = { notepad: 'notepad.exe', calculator: 'calc.exe', calc: 'calc.exe', paint: 'mspaint.exe', explorer: 'explorer.exe', 'file explorer': 'explorer.exe' };
h('sys:open', async ({ name }) => {
  const exe = APPS[String(name).toLowerCase()];
  if (!exe) throw new Error('I can only open notepad, calculator, paint and file explorer.');
  const c = await dialog.showMessageBox(win, { type: 'question', buttons: ['Open', 'Cancel'], defaultId: 0, cancelId: 1, message: `NERTZ wants to open ${name}.` });
  if (c.response !== 0) return { done: false };
  await new Promise((res, rej) => { const p = spawn(exe, [], { detached: true, stdio: 'ignore' }); p.once('error', rej); p.once('spawn', () => { p.unref(); res(); }); });
  return { done: true };
});
h('img:pick', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp'] }] });
  if (r.canceled) return { canceled: true };
  const f = r.filePaths[0]; if (fs.statSync(f).size > 25e6) throw new Error('That image is larger than 25 MB.');
  const ext = path.extname(f).slice(1).toLowerCase();
  return { dataUrl: `data:image/${ext === 'jpg' ? 'jpeg' : ext};base64,` + fs.readFileSync(f).toString('base64'), name: path.basename(f) };
});
h('hist:get', async () => ({ m: rd('history.json', []) }));
h('hist:set', async ({ m }) => { wr('history.json', (m || []).slice(-200)); return {}; });
h('hist:clear', async () => { wr('history.json', []); return {}; });
h('mem:get', async () => ({ l: rd('memory.json', []) }));
h('mem:set', async ({ l }) => { wr('memory.json', (l || []).slice(0, 100)); return {}; });
h('app:info', async () => ({ version: app.getVersion(), electron: process.versions.electron, chrome: process.versions.chrome, arch: process.arch, os: process.platform + ' ' + process.getSystemVersion() }));
h('app:fs', async () => { win.setFullScreen(!win.isFullScreen()); return {}; });
let alive = false;
h('ui:alive', async () => { alive = true; return {}; });
h('app:quit', async () => { app.quit(); return {}; });

/* ---- window ---- */
function create() {
  win = new BrowserWindow({ show: false, fullscreen: true, backgroundColor: '#000000', autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
  Menu.setApplicationMenu(null);
  win.once('ready-to-show', () => win.show());
  win.webContents.on('console-message', (_e, level, msg, line, src) => { if (level >= 2) log(`renderer ${level === 3 ? 'error' : 'warning'}: ${msg} (${path.basename(src || '')}:${line})`); });
  win.webContents.on('did-fail-load', (_e, code, desc) => log('load failed ' + code + ' ' + desc));
  win.webContents.on('render-process-gone', (_e, d) => { log('renderer gone: ' + d.reason); if (!fs.existsSync(P('nogpu'))) compatRestart(); });
  setTimeout(async () => {
    if (alive || !win || win.isDestroyed()) return; log('watchdog: interface did not start');
    const r = await dialog.showMessageBox(win, { type: 'warning', buttons: ['Restart in compatibility mode', 'Open log folder', 'Quit'], defaultId: 0, cancelId: 2,
      message: 'NERTZ did not start properly.', detail: 'A log was saved to ' + P('nertz.log') });
    if (r.response === 0) compatRestart(); else if (r.response === 1) shell.openPath(app.getPath('userData')); else app.quit();
  }, 12000);
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', e => e.preventDefault());
  win.webContents.on('before-input-event', (e, i) => {
    if (i.type !== 'keyDown') return;
    if (i.key === 'F11') { win.setFullScreen(!win.isFullScreen()); e.preventDefault(); }
    else if (i.key === 'F12' || (i.control && i.shift && i.key.toLowerCase() === 'i')) win.webContents.toggleDevTools();
    else if (i.control && i.shift && i.key.toLowerCase() === 'g') { // toggle compatibility mode (software rendering) and restart
      if (fs.existsSync(P('nogpu'))) { try { fs.unlinkSync(P('nogpu')); } catch {} app.relaunch(); app.exit(0); } else compatRestart(); }
  });
}
app.whenReady().then(() => {
  session.defaultSession.setPermissionRequestHandler((_w, perm, cb, d) => cb(perm === 'media' && String(d.requestingUrl).startsWith('file://')));
  session.defaultSession.setPermissionCheckHandler((_w, perm) => perm === 'media');
  create();
});
app.on('child-process-gone', (_e, d) => { log('child gone: ' + d.type + ' ' + d.reason); if (d.type === 'GPU' && !fs.existsSync(P('nogpu'))) compatRestart(); });
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('window-all-closed', () => app.quit());
