'use strict';
/* Sound: original synthesized startup. Voice: Windows speech output. Mic: record + silence detection. */
const Sound = (() => {
  let ctx, vol = .6, on = true;
  const C = () => { if (!ctx) ctx = new AudioContext(); if (ctx.state === 'suspended') ctx.resume(); return ctx; };
  function beep(fr, when, len, v = .25) { const c = C(), o = c.createOscillator(), g = c.createGain(); o.type = 'sine'; o.frequency.value = fr;
    g.gain.setValueAtTime(0, when); g.gain.linearRampToValueAtTime(v * vol, when + .02); g.gain.exponentialRampToValueAtTime(.001, when + len);
    o.connect(g).connect(c.destination); o.start(when); o.stop(when + len + .05); }
  return {
    config(enabled, v) { on = enabled; vol = v; },
    boot(dur) { if (!on || vol <= 0) return; const c = C(), n = c.currentTime, m = c.createGain(); m.gain.value = vol; m.connect(c.destination);
      const o1 = c.createOscillator(), g1 = c.createGain(); o1.type = 'sine'; o1.frequency.setValueAtTime(38, n); o1.frequency.exponentialRampToValueAtTime(74, n + dur);
      g1.gain.setValueAtTime(0, n); g1.gain.linearRampToValueAtTime(.8, n + 1); g1.gain.linearRampToValueAtTime(.5, n + dur); g1.gain.linearRampToValueAtTime(0, n + dur + .6);
      o1.connect(g1).connect(m); o1.start(n); o1.stop(n + dur + .7);
      const o2 = c.createOscillator(), f = c.createBiquadFilter(), g2 = c.createGain(); o2.type = 'sawtooth'; f.type = 'lowpass'; f.Q.value = 8;
      o2.frequency.setValueAtTime(110, n); o2.frequency.exponentialRampToValueAtTime(900, n + dur); f.frequency.setValueAtTime(200, n); f.frequency.exponentialRampToValueAtTime(5200, n + dur);
      g2.gain.setValueAtTime(0, n); g2.gain.linearRampToValueAtTime(.12, n + dur * .9); g2.gain.linearRampToValueAtTime(0, n + dur + .1);
      o2.connect(f).connect(g2).connect(m); o2.start(n); o2.stop(n + dur + .2); },
    ping(i) { if (on && vol > 0) beep(330 * Math.pow(1.335, i), C().currentTime, .3, .18); },
    confirm(ok) { if (!on || vol <= 0) return; const n = C().currentTime; beep(660, n, .25); beep(ok ? 990 : 440, n + .18, ok ? .4 : .5); },
    tick() { if (on && vol > 0) beep(1800, C().currentTime, .04, .08); }
  };
})();

const Voice = (() => {
  let vol = 1, name = '', pulse = null, tok = 0;
  const clean = t => String(t).replace(/https?:\/\/\S+/g, '').replace(/[*#`_>]/g, '').replace(/\s+/g, ' ').trim().slice(0, 900);
  const list = () => speechSynthesis.getVoices();
  const pick = () => list().find(v => v.name === name) || list().find(v => /^en/i.test(v.lang) && /david|mark|george|guy|james|richard|ryan|male/i.test(v.name)) || list().find(v => /^en/i.test(v.lang));
  function stop() { tok++; speechSynthesis.cancel(); clearInterval(pulse); Orb.setLevel(0); }
  function speak(text) {
    return new Promise(res => {
      stop(); const my = tok, u = new SpeechSynthesisUtterance(clean(text)), v = pick();
      if (v) u.voice = v; u.volume = vol; u.pitch = .8; u.rate = .97;
      u.onstart = () => { if (my !== tok) return; Orb.setState('speaking'); pulse = setInterval(() => Orb.setLevel(.4 + Math.random() * .6), 110); };
      const end = () => { if (my === tok) { clearInterval(pulse); Orb.setLevel(0); Orb.toRest(); } res(); };
      u.onend = end; u.onerror = end; speechSynthesis.speak(u);
    });
  }
  return { speak, stop, list, config(n, v) { name = n; vol = v; }, speaking: () => speechSynthesis.speaking };
})();

const Mic = (() => {
  let stream, ctx, raf, cancelled = false, rec;
  const cleanup = () => { cancelAnimationFrame(raf); try { stream?.getTracks().forEach(t => t.stop()); } catch {} try { ctx?.close(); } catch {} Orb.setLevel(0); };
  /* Resolves {b64, mime} after speech then silence, or null if nothing was heard / cancelled. */
  async function listen(deviceId) {
    cancelled = false;
    stream = await navigator.mediaDevices.getUserMedia({ audio: deviceId ? { deviceId: { exact: deviceId } } : true });
    ctx = new AudioContext(); const an = ctx.createAnalyser(); an.fftSize = 512; ctx.createMediaStreamSource(stream).connect(an);
    const chunks = []; rec = new MediaRecorder(stream); rec.ondataavailable = e => chunks.push(e.data);
    return new Promise(res => {
      let heard = false, lastLoud = 0; const t0 = performance.now(), buf = new Uint8Array(an.fftSize);
      rec.onstop = async () => {
        cleanup(); if (cancelled || !heard) return res(null);
        const blob = new Blob(chunks, { type: rec.mimeType }), fr = new FileReader();
        fr.onload = () => res({ b64: String(fr.result).split(',')[1], mime: rec.mimeType }); fr.readAsDataURL(blob);
      };
      rec.start();
      (function loop() {
        an.getByteTimeDomainData(buf); let s = 0; for (const b of buf) { const d = (b - 128) / 128; s += d * d; }
        const rms = Math.sqrt(s / buf.length), now = performance.now(); Orb.setLevel(Math.min(1, rms * 6));
        if (rms > .03) { heard = true; lastLoud = now; }
        if ((heard && now - lastLoud > 1300) || (!heard && now - t0 > 7000) || now - t0 > 30000 || cancelled) { if (rec.state !== 'inactive') rec.stop(); return; }
        raf = requestAnimationFrame(loop);
      })();
    });
  }
  return { listen, cancel() { cancelled = true; if (rec && rec.state !== 'inactive') rec.stop(); else cleanup(); }, active: () => !!rec && rec.state === 'recording' };
})();
