'use strict';
addEventListener('error', e => { const r = document.getElementById('reply'); if (r) r.textContent = 'Error: ' + e.message; });
addEventListener('unhandledrejection', e => { const r = document.getElementById('reply'); if (r) r.textContent = 'Error: ' + (e.reason && e.reason.message || e.reason); });
if (!window.nertz) { document.getElementById('reply').textContent = 'Startup error: the secure bridge (preload) did not load.'; throw new Error('preload missing'); }
const $ = id => document.getElementById(id);
const el = (t, c, x) => { const e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; };
const S = { set: {}, hasAi: false, hasSearch: false, st: { internet: false, aiConfigured: false }, convo: [], mem: [], typed: '', ready: false,
  req: 0, review: null, image: null, region: null, zoom: 1, micAsked: false, lastOnline: null };
const quiet = t => { $('reply').textContent = t; };
const say = t => { quiet(t); return Voice.speak(t); };
const name = () => S.set.userName || 'sir';
const stopAll = () => { S.req++; Voice.stop(); Mic.cancel(); Orb.toRest(); };

/* ---------- settings + status ---------- */
function applySettings() {
  const s = S.set; Orb.config({ i: +s.intensity || 1, reduced: !!s.reducedMotion }); Voice.config(s.voice, +s.voiceVolume);
  Sound.config(!!s.startupSound, +s.startupVolume);
}
async function loadAll() {
  const r = await nertz.settings(); S.set = r.settings; S.hasAi = r.hasAiKey; S.hasSearch = r.hasSearchKey; applySettings();
  S.convo = (await nertz.hist.get()).m || []; S.mem = (await nertz.mem.get()).l || [];
}
function label(st) {
  if (!st.internet && st.local && st.aiConfigured) return ['OFFLINE · LOCAL AI READY', 'warn'];
  if (!st.internet) return ['SYSTEM OFFLINE', 'err'];
  if (!st.aiConfigured) return ['ONLINE · AI NOT CONFIGURED', 'warn'];
  return ['SYSTEM ONLINE', 'ok'];
}
async function refreshStatus(announce) {
  const r = await nertz.status(); S.st = r; const [txt, cls] = label(r);
  const s = $('status'); s.textContent = `● ${txt}  ·  SEARCH ${r.searchConfigured ? 'READY' : 'OFF'}`; s.className = cls === 'ok' ? '' : 'warn';
  Orb.setRest(cls === 'err' ? 'error' : 'idle');
  if (announce && S.lastOnline !== null && S.lastOnline !== r.internet && S.ready) say(r.internet ? 'Connection restored. System online.' : 'Connection lost. System offline.');
  S.lastOnline = r.internet; return [txt, cls];
}

/* ---------- startup ---------- */
async function boot() {
  await loadAll(); Orb.onPing(i => Sound.ping(i));
  const dur = S.set.reducedMotion ? 1.2 : 3.6, t0 = performance.now(); try { Sound.boot(dur); } catch {}
  await new Promise(res => (function up() { const k = Math.min(1, (performance.now() - t0) / (dur * 1000)); Orb.setPower(k); k < 1 ? requestAnimationFrame(up) : res(); })());
  const [txt, cls] = await refreshStatus(false);
  $('stat').textContent = txt; $('stat').style.color = cls === 'ok' ? '' : '#ffb347';
  Orb.titleMode(true); $('title').style.opacity = 1; $('flash').style.opacity = 1; setTimeout(() => $('flash').style.opacity = 0, 500);
  try { Sound.confirm(cls !== 'err'); } catch {}
  const n = name(), msg = cls === 'ok' ? `Welcome back, ${n}. System online.`
    : cls === 'err' ? `Welcome back, ${n}. System offline. Features that need the internet are unavailable.`
    : S.st.internet ? `Welcome back, ${n}. System online, but no AI provider is configured. Open settings to add a key.`
    : `Welcome back, ${n}. System offline. Gemini needs an internet connection.`;
  setTimeout(() => say(msg), 700);
  setTimeout(() => { $('title').style.opacity = 0; Orb.titleMode(false); S.ready = true; render(); }, 3800);
  setInterval(() => refreshStatus(true), 25000);
}

async function start() {
  nertz.alive();
  try { await boot(); } catch (err) { Orb.setPower(1); quiet('Startup problem: ' + (err && err.message)); S.ready = true; render(); }
}

/* ---------- keyboard ---------- */
function render() { const t = $('typed'); t.textContent = S.typed; if (S.ready) t.appendChild(el('i')); }
const settingsOpen = () => !$('settings').hidden, camOpen = () => !$('cam').hidden;
addEventListener('keydown', e => {
  if (e.ctrlKey && e.key === ',') { e.preventDefault(); openSettings(); return; }
  if (e.ctrlKey && e.key.toLowerCase() === 'q') { nertz.quit(); return; }
  if (e.key === 'Escape') {
    if (Voice.speaking() || Mic.active() || ['thinking', 'researching'].includes(Orb.state())) { stopAll(); quiet(''); return; }
    if (camOpen()) return closeCam(); if (settingsOpen()) return closeSettings();
    if (document.body.classList.contains('review')) closeReview(); return;
  }
  if (!S.ready || settingsOpen() || camOpen() || e.ctrlKey || e.metaKey || e.altKey || /INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) return;
  if (e.key === 'Enter') { const q = S.typed.trim(); S.typed = ''; render(); if (q) submit(q); return; }
  if (e.key === 'Backspace') { S.typed = S.typed.slice(0, -1); render(); return; }
  if ((e.key === 'm' || e.key === 'M') && !S.typed) { e.preventDefault(); listen(); return; }
  if (e.key.length === 1) { if (Voice.speaking()) Voice.stop(); S.typed += e.key; Sound.tick(); render(); e.preventDefault(); }
});
Orb.el.onclick = () => { if (S.ready) { stopAll(); } };
$('gear').onclick = openSettings;

/* ---------- voice input ---------- */
async function listen() {
  if (Mic.active()) { Mic.cancel(); return; }
  stopAll();
  if (!S.st.internet && !S.st.local) { say('Voice input needs an internet connection, and I am offline.'); return; }
  if (!S.micAsked) { S.micAsked = true; quiet('I need microphone access to hear you. Please allow the Windows prompt.'); }
  Orb.setState('listening'); quiet('Listening…');
  let rec;
  try { rec = await Mic.listen(S.set.mic || undefined); }
  catch (err) { Orb.toRest(); return say(err.name === 'NotAllowedError' || err.name === 'SecurityError'
    ? 'Microphone access is blocked. Enable it in Windows Settings, Privacy and security, Microphone.' : 'I could not open the microphone. Check that one is connected.'); }
  if (!rec) { Orb.toRest(); return quiet('I did not hear anything.'); }
  const my = ++S.req; Orb.setState('thinking'); quiet('Transcribing…');
  const r = await nertz.stt(rec); if (my !== S.req) return;
  if (!r.ok) { Orb.toRest(); return say(r.error); }
  if (!r.text.trim()) { Orb.toRest(); return quiet('I could not make out any words.'); }
  S.typed = r.text.trim(); render(); setTimeout(() => { const q = S.typed; S.typed = ''; render(); submit(q); }, 400);
}

/* ---------- intent routing ---------- */
const REVIEW = /\b(review|investigate|analy[sz]e|compare|comparison)\b/i;
const FRESH = /\b(latest|current|currently|today|tonight|news|price|prices|release|released|score|weather|who is|who won|this week|202\d)\b/i;
function submit(q) {
  let m;
  if (/^(new|clear) (conversation|chat)$/i.test(q)) { S.convo = []; nertz.hist.set([]); return say('Starting a fresh conversation.'); }
  if (/^(show |open )?settings$/i.test(q)) return openSettings();
  if (/^(show )?(transcript|history)$/i.test(q)) { openSettings(); $('s_trans').click(); return; }
  if (/^(close|exit|done|back)( review)?$/i.test(q)) { closeReview(); return say('Returning to main mode.'); }
  if ((m = /^remember(?: that)? (.+)/i.exec(q))) return remember(m[1]);
  if ((m = /^open (notepad|calculator|calc|paint|file explorer|explorer)\b/i.exec(q))) return openApp(m[1]);
  if ((m = /^open (https?:\/\/\S+|www\.\S+)/i.exec(q))) return openLink(m[1]);
  if (/^(use|open) (the )?camera$/i.test(q)) return openCam();
  if (/^(look at|load|open|add|analy[sz]e|inspect) (an |the |a )?(image|photo|picture)$/i.test(q)) return addImage();
  if (REVIEW.test(q)) return doReview(q);
  if (S.image && (S.region || /\b(this|image|photo|picture|part|region|here|it)\b/i.test(q))) return askImage(q);
  return ask(q);
}
async function remember(t) {
  if (!S.set.memoryOn) return say('Memory is turned off in settings.');
  if (/sk-|password|passcode|api[ -]?key|secret|token/i.test(t)) return say('I will not store passwords or keys in memory.');
  S.mem.unshift(t.slice(0, 300)); await nertz.mem.set(S.mem); say('Noted. You can review or delete that in settings.');
}
async function openApp(n) { const r = await nertz.sysOpen(n); say(!r.ok ? r.error : r.done ? `Opened ${n}.` : 'Cancelled. I did not open anything.'); }
async function openLink(u) { const r = await nertz.open(/^www\./i.test(u) ? 'https://' + u : u); say(r.ok ? 'Opening that in your browser.' : r.error); }

/* ---------- AI ---------- */
function system() {
  const mem = S.set.memoryOn && S.mem.length ? '\nUser-approved memory:\n- ' + S.mem.slice(0, 20).join('\n- ') : '';
  return `You are NERTZ, a calm, precise, male-presenting desktop AI assistant. Address the user as "${name()}" only when natural.
Lead with the answer, keep spoken replies short, be honest about uncertainty, never invent facts, sources, prices, specs, searches or completed actions.
Separate facts, estimates, opinions and recommendations. Never claim to have controlled the computer. Today is ${new Date().toDateString()}.
Search is ${S.st.searchConfigured ? 'available' : 'NOT configured'}; internet is ${S.st.internet ? 'online' : 'offline'}.${mem}${S.ctx ? '\nActive review context:\n' + S.ctx : ''}`;
}
const recent = () => S.convo.slice(-16).map(m => ({ role: m.role, content: m.content }));
function save(role, content) { S.convo.push({ role, content }); nertz.hist.set(S.convo); }
async function fail(msg) { Orb.setState('error'); await say(msg); setTimeout(() => { if (Orb.state() === 'error') Orb.toRest(); }, 1500); }

async function ask(q, extra) {
  const my = ++S.req; let results = [], note = '';
  const useSearch = FRESH.test(q) && S.st.searchConfigured && S.st.internet;
  Orb.setState(useSearch ? 'researching' : 'thinking'); quiet(useSearch ? 'Searching…' : 'Thinking…');
  if (useSearch) { const s = await nertz.search(q); if (my !== S.req) return; if (s.ok) results = s.results; else note = s.error; }
  const ctx = results.length ? '\n\nWeb search results (cite by title, mention dates):\n' + results.map((r, i) => `[${i + 1}] ${r.title} ${r.date} ${r.url}\n${r.snippet}`).join('\n') : FRESH.test(q) && !S.st.searchConfigured ? '\n\n(Note: web search is not configured; answer from built-in knowledge and say it may be out of date.)' : '';
  const r = await nertz.chat({ system: system(), messages: [...recent(), { role: 'user', content: q + ctx, images: extra?.images }] });
  if (my !== S.req) return; if (!r.ok) return fail(r.error);
  save('user', q); save('assistant', r.text + (results.length ? '\nSources: ' + results.map(x => x.url).join(' ') : '')); say(r.text);
}

/* ---------- review mode ---------- */
const REVIEW_SYS = `Return ONLY one JSON object, no markdown fences: {"title":string,"spoken":string (max 2 short sentences),"facts":[{"label":string,"value":string,"kind":"verified"|"estimate"|"opinion"}],"pros":[string],"cons":[string],"risks":[string],"alternatives":[{"name":string,"note":string}],"price":string|null,"verdict":string}. Include only sections relevant to the subject; use [] or null otherwise. Base claims on the supplied search results when present; write "Not verified" when unsupported. Never invent ratings, scores, prices or specifications.`;
async function doReview(q) {
  const my = ++S.req, subject = q.replace(/^(please )?(can you )?(review|investigate|analy[sz]e)\s+(the |this |a |an )?/i, '').trim() || q;
  openWorkspace(subject); Orb.setState(S.st.searchConfigured ? 'researching' : 'thinking'); quiet('Investigating…');
  let results = [], note = '';
  if (S.st.searchConfigured && S.st.internet) { const s = await nertz.search(subject + ' review specifications'); if (my !== S.req) return; if (s.ok) results = s.results; else note = 'Search failed: ' + s.error; }
  else note = S.st.searchConfigured ? 'You appear to be offline, so no web sources were used.' : 'Web search is not configured, so this review comes from built-in knowledge, may be out of date, and has no web sources.';
  const ctx = results.length ? '\n\nSearch results:\n' + results.map((r, i) => `[${i + 1}] ${r.title} ${r.date} ${r.url}\n${r.snippet}`).join('\n') : '';
  const r = await nertz.chat({ system: system() + '\n' + REVIEW_SYS, messages: [{ role: 'user', content: `Review: ${q}${ctx}`, images: S.image ? [S.image] : undefined }] });
  if (my !== S.req) return; if (!r.ok) { $('ws').querySelector('.sub').textContent = r.error; return fail(r.error); }
  let d; try { d = JSON.parse(r.text.slice(r.text.indexOf('{'), r.text.lastIndexOf('}') + 1)); } catch { d = { title: subject, spoken: r.text.slice(0, 300), verdict: r.text }; }
  S.review = d; S.ctx = `Subject: ${d.title || subject}\nSummary: ${d.verdict || d.spoken || ''}\nSources: ${results.map(x => x.title + ' ' + x.url).join('; ')}`;
  fillReview(d, results, note); save('user', q); save('assistant', d.spoken || d.verdict || ''); say(d.spoken || 'The review is ready.');
}
function openWorkspace(subject) {
  const ws = $('ws'); ws.textContent = ''; ws.appendChild(el('h1', '', String(subject).toUpperCase().slice(0, 60))); ws.appendChild(el('div', 'sub', 'Investigation in progress…'));
  ws.appendChild(el('div', 'tools')); const t = ws.lastChild; t.className = 'r';
  [['ADD IMAGE', addImage], ['CAMERA', openCam], ['CLOSE REVIEW', closeReview]].forEach(([l, f]) => { const b = el('button', '', l); b.onclick = f; t.appendChild(b); });
  ws.appendChild(el('div', '', '')).id = 'imgslot'; if (S.image) showImage();
  document.body.classList.add('review'); ws.scrollTop = 0;
}
function block(title) { const b = el('div', 'blk'); if (title) b.appendChild(el('h2', '', title)); $('ws').appendChild(b); return b; }
function list(items) { const u = el('ul'); items.forEach(i => u.appendChild(el('li', '', i))); return u; }
function fillReview(d, results, note) {
  $('ws').querySelector('.sub').textContent = note || 'Findings'; $('ws').querySelector('.sub').className = note ? 'sub warn' : 'sub';
  const steps = [];
  if (d.facts?.length) steps.push(() => { const b = block('KEY FACTS'), u = el('ul'); d.facts.forEach(f => { const li = el('li', '', `${f.label}: ${f.value}`); li.appendChild(el('span', 'tag' + (f.kind === 'verified' ? '' : ' e'), f.kind || 'estimate')); u.appendChild(li); }); b.appendChild(u); return b; });
  if (d.pros?.length || d.cons?.length) steps.push(() => { const b = block(''), r = el('div', 'row'); [['PROS', d.pros], ['CONS', d.cons]].forEach(([t, a]) => { const c = el('div'); c.appendChild(el('h2', '', t)); c.appendChild(list(a || [])); r.appendChild(c); }); b.appendChild(r); return b; });
  if (d.risks?.length) steps.push(() => { const b = block('RISKS + LIMITATIONS'); b.appendChild(list(d.risks)); return b; });
  if (d.alternatives?.length) steps.push(() => { const b = block('ALTERNATIVES'); b.appendChild(list(d.alternatives.map(a => `${a.name}: ${a.note}`))); return b; });
  if (d.price) steps.push(() => { const b = block('PRICE + VALUE'); b.appendChild(el('div', '', d.price)); return b; });
  if (d.verdict) steps.push(() => { const b = block('VERDICT'); b.appendChild(el('div', '', d.verdict)); return b; });
  steps.push(() => { const b = block('SOURCES'); if (!results.length) b.appendChild(el('div', 'warn', 'No web sources were used for this review.'));
    results.forEach(r => { const p = el('div', 'src'), a = el('a', '', r.title || r.url); a.onclick = () => nertz.open(r.url); p.appendChild(a); p.appendChild(el('small', '', (r.date ? r.date + ' · ' : '') + r.url)); b.appendChild(p); }); return b; });
  steps.forEach((f, i) => setTimeout(() => { const b = f(); requestAnimationFrame(() => b.classList.add('on')); }, 500 + i * 800));
}
function closeReview() { document.body.classList.remove('review'); S.region = null; }

/* ---------- images: file, camera, region selection ---------- */
function shrink(dataUrl, max = 1600) {
  return new Promise((res, rej) => { const im = new Image(); im.onerror = () => rej(new Error('That image could not be read.'));
    im.onload = () => { const k = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement('canvas'); c.width = im.width * k; c.height = im.height * k;
      c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL('image/jpeg', .88)); }; im.src = dataUrl; });
}
function crop(dataUrl, r) {
  return new Promise(res => { const im = new Image(); im.onload = () => { const sx = r.x * im.width, sy = r.y * im.height, sw = Math.max(8, r.w * im.width), sh = Math.max(8, r.h * im.height), c = document.createElement('canvas');
    c.width = Math.min(1024, sw); c.height = Math.max(8, c.width * sh / sw); c.getContext('2d').drawImage(im, sx, sy, sw, sh, 0, 0, c.width, c.height); res(c.toDataURL('image/jpeg', .9)); }; im.src = dataUrl; });
}
async function setImage(url) { S.image = await shrink(url); S.region = null; if (!document.body.classList.contains('review')) openWorkspace('Image'), $('ws').querySelector('.sub').textContent = 'Click or drag on the image, then ask a question.'; showImage(); }
async function addImage() { const r = await nertz.pickImage(); if (r.ok && !r.canceled) { try { await setImage(r.dataUrl); say('Image loaded. Select a region and ask me about it.'); } catch (e) { say(e.message); } } else if (!r.ok) say(r.error); }
function showImage() {
  const slot = $('imgslot'); if (!slot) return; slot.textContent = ''; const box = el('div'), inn = el('div'); box.id = 'imgbox'; inn.id = 'imgin';
  const img = el('img'); img.src = S.image; const sel = el('div'); sel.id = 'sel'; inn.append(img, sel); box.appendChild(inn); slot.appendChild(box);
  const tools = el('div', 'r'); [['ZOOM +', 0.5], ['ZOOM −', -0.5]].forEach(([l, d]) => { const b = el('button', '', l); b.onclick = () => { S.zoom = Math.max(1, Math.min(4, S.zoom + d)); inn.style.width = S.zoom * 100 + '%'; }; tools.appendChild(b); });
  const wb = el('button', '', 'WHAT IS THIS REGION?'); wb.onclick = () => askImage('What is this part, and what does it do? Say what is clearly visible versus uncertain.'); tools.appendChild(wb);
  const cb = el('button', '', 'CLEAR SELECTION'); cb.onclick = () => { S.region = null; sel.style.display = 'none'; }; tools.appendChild(cb); slot.appendChild(tools);
  inn.style.width = S.zoom * 100 + '%'; let d = null;
  const pt = ev => { const r = inn.getBoundingClientRect(); return [Math.max(0, Math.min(1, (ev.clientX - r.left) / r.width)), Math.max(0, Math.min(1, (ev.clientY - r.top) / r.height))]; };
  const paint = r => Object.assign(sel.style, { display: 'block', left: r.x * 100 + '%', top: r.y * 100 + '%', width: r.w * 100 + '%', height: r.h * 100 + '%' });
  inn.onpointerdown = ev => { d = pt(ev); inn.setPointerCapture(ev.pointerId); };
  inn.onpointermove = ev => { if (!d) return; const p = pt(ev); paint({ x: Math.min(d[0], p[0]), y: Math.min(d[1], p[1]), w: Math.abs(p[0] - d[0]), h: Math.abs(p[1] - d[1]) }); };
  inn.onpointerup = ev => { if (!d) return; const p = pt(ev); let r = { x: Math.min(d[0], p[0]), y: Math.min(d[1], p[1]), w: Math.abs(p[0] - d[0]), h: Math.abs(p[1] - d[1]) }; d = null;
    if (r.w < .02 && r.h < .02) { r = { x: Math.max(0, p[0] - .08), y: Math.max(0, p[1] - .08), w: .16, h: .16 }; }  // a click selects a small area
    S.region = r; paint(r); quiet('Region selected. Ask a question or press WHAT IS THIS REGION.'); };
}
async function askImage(q) {
  const images = S.region ? [await crop(S.image, S.region), S.image] : [S.image];
  const pre = S.region ? 'The first image is the region the user selected; the second is the full image. ' : 'This is the full image. ';
  return ask(pre + q, { images });
}
let camStream;
async function openCam() {
  try { camStream = await navigator.mediaDevices.getUserMedia({ video: true }); } catch (err) {
    return say(err.name === 'NotAllowedError' ? 'Camera access is blocked. Enable it in Windows Settings, Privacy and security, Camera.' : 'I could not find a camera.'); }
  $('vid').srcObject = camStream; $('cam').hidden = false;
}
function closeCam() { camStream?.getTracks().forEach(t => t.stop()); $('cam').hidden = true; }
$('camx').onclick = closeCam;
$('snap').onclick = async () => { const v = $('vid'), c = document.createElement('canvas'); c.width = v.videoWidth; c.height = v.videoHeight; c.getContext('2d').drawImage(v, 0, 0); closeCam(); await setImage(c.toDataURL('image/jpeg', .9)); say('Photo captured. Select a region and ask me about it.'); };

/* ---------- settings panel ---------- */
async function openSettings() {
  $('settings').hidden = false;   // show first, then fill in, so a problem below can never keep the panel closed
  const s = S.set, v = (id, x) => { try { $(id).value = x ?? ''; } catch {} }, c = (id, x) => { try { $(id).checked = !!x; } catch {} };
  v('s_model', s.model); v('s_sprov', s.searchProvider); v('s_name', s.userName);
  v('s_vvol', s.voiceVolume); v('s_svol', s.startupVolume); v('s_int', s.intensity); c('s_sound', s.startupSound); c('s_reduce', s.reducedMotion); c('s_mem', s.memoryOn);
  $('s_keyst').textContent = S.hasAi ? 'Key saved' : 'No key'; $('s_skeyst').textContent = S.hasSearch ? 'Key saved' : 'No key'; $('trans').hidden = true;
  try { const vs = $('s_voice'); vs.textContent = ''; vs.appendChild(new Option('Auto (male English)', '')); Voice.list().forEach(x => vs.appendChild(new Option(`${x.name} (${x.lang})`, x.name))); vs.value = s.voice || ''; } catch {}
  try { drawMem(); } catch {}
  try { const ms = $('s_mic'); ms.textContent = ''; ms.appendChild(new Option('Default microphone', ''));
    const devs = await Promise.race([navigator.mediaDevices.enumerateDevices(), new Promise(r => setTimeout(() => r([]), 2000))]);
    devs.filter(d => d.kind === 'audioinput').forEach((d, i) => ms.appendChild(new Option(d.label || 'Microphone ' + (i + 1), d.deviceId))); ms.value = s.mic || ''; } catch {}
  try { diag(); } catch {}
  setTimeout(() => { try { $('s_key').focus(); } catch {} }, 50);
}
async function diag() {
  const i = (await nertz.info()), q = async n => { try { return (await navigator.permissions.query({ name: n })).state; } catch { return 'unknown'; } };
  await refreshStatus(false);
  $('s_diag').textContent = `Version ${i.version} (${i.arch})\nElectron ${i.electron} · Chromium ${i.chrome}\n${i.os}\nInternet: ${S.st.internet ? 'connected' : 'not reachable'}\nAI: ${S.st.aiConfigured ? 'configured' : 'not configured'}\nSearch: ${S.st.searchConfigured ? 'configured' : 'not configured'}\nMicrophone permission: ${await q('microphone')}\nCamera permission: ${await q('camera')}`;
}
function closeSettings() { $('settings').hidden = true; }
function drawMem() { const m = $('memlist'); m.textContent = ''; S.mem.forEach((t, i) => { const r = el('div'); r.appendChild(el('span', '', t)); const b = el('button', '', 'DELETE'); b.onclick = async () => { S.mem.splice(i, 1); await nertz.mem.set(S.mem); drawMem(); }; r.appendChild(b); m.appendChild(r); }); if (!S.mem.length) m.appendChild(el('div', 'n', 'No saved memories.')); }
const bind = (id, key, get) => $(id).addEventListener('change', async () => { S.set[key] = get($(id)); await nertz.setSettings({ [key]: S.set[key] }); applySettings(); });
[['s_model', 'model'], ['s_sprov', 'searchProvider'], ['s_name', 'userName'], ['s_mic', 'mic'], ['s_voice', 'voice']].forEach(([i, k]) => bind(i, k, e => e.value.trim()));
[['s_vvol', 'voiceVolume'], ['s_svol', 'startupVolume'], ['s_int', 'intensity']].forEach(([i, k]) => bind(i, k, e => +e.value));
[['s_sound', 'startupSound'], ['s_reduce', 'reducedMotion'], ['s_mem', 'memoryOn']].forEach(([i, k]) => bind(i, k, e => e.checked));
async function saveKey(kind, inp, st) {
  st.textContent = 'Validating…'; const r = await nertz.saveKey(kind, inp.value); inp.value = '';
  if (r.ok) { if (kind === 'ai') { S.hasAi = true; S.set.provider = 'gemini'; } else S.hasSearch = true; st.textContent = 'Key valid and saved'; await refreshStatus(false); } else st.textContent = r.error;
}
$('s_keybtn').onclick = () => saveKey('ai', $('s_key'), $('s_keyst')); $('s_skeybtn').onclick = () => saveKey('search', $('s_skey'), $('s_skeyst'));
$('s_keyclr').onclick = async () => { await nertz.clearKey('ai'); S.hasAi = false; $('s_keyst').textContent = 'Key removed'; refreshStatus(false); };
$('s_skeyclr').onclick = async () => { await nertz.clearKey('search'); S.hasSearch = false; $('s_skeyst').textContent = 'Key removed'; refreshStatus(false); };
$('s_trans').onclick = () => { const t = $('trans'); t.textContent = S.convo.map(m => (m.role === 'user' ? 'YOU: ' : 'NERTZ: ') + m.content).join('\n\n') || 'No conversation history.'; t.hidden = false; };
$('s_clear').onclick = async () => { S.convo = []; await nertz.hist.clear(); $('trans').textContent = 'History cleared.'; $('trans').hidden = false; };
$('s_close').onclick = closeSettings;

start();
