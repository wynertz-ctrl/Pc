'use strict';
const { contextBridge, ipcRenderer } = require('electron');
const inv = (c, a) => ipcRenderer.invoke(c, a);
contextBridge.exposeInMainWorld('nertz', {
  settings: () => inv('settings:get'), setSettings: p => inv('settings:set', p),
  saveKey: (kind, value) => inv('key:save', { kind, value }), clearKey: kind => inv('key:clear', { kind }),
  status: () => inv('status'), alive: () => inv('ui:alive'), chat: a => inv('ai:chat', a), search: q => inv('search:web', { q }),
  stt: a => inv('stt', a), open: url => inv('ext:open', { url }), sysOpen: name => inv('sys:open', { name }),
  pickImage: () => inv('img:pick'), info: () => inv('app:info'), fullscreen: () => inv('app:fs'), quit: () => inv('app:quit'),
  hist: { get: () => inv('hist:get'), set: m => inv('hist:set', { m }), clear: () => inv('hist:clear') },
  mem: { get: () => inv('mem:get'), set: l => inv('mem:set', { l }) }
});
