'use strict';
/* Orb: flat circular HUD (idle / listening / thinking) that tilts in real 3D into a spinning holographic disc while speaking.
   Every layer is a ring in its own plane; the planes are rotated, foreshortened and stacked in depth, so the motion is true rotation. */
const Orb = (() => {
  const cv = document.getElementById('cv'), g = cv.getContext('2d'), R = 450, TAU = Math.PI * 2;
  const LBL = ['AM OFF', 'GAME', 'DESK', 'AM ON', 'NEXT', 'LOCK', 'HOME', 'SYNC', 'CTRL', 'DOCS', 'COMP', 'UP'];
  const SPD = { idle: 1, listening: 1.3, thinking: 2.4, researching: 1.8, speaking: 1.6, error: .35 };
  let power = 0, state = 'idle', rest = 'idle', level = 0, lv = 0, ph = 0, sp = 1, form = 0, last = performance.now(), titleOn = false;
  let onPing = () => {}; const cfg = { i: 1, reduced: false }; const pinged = [];
  const sd = n => { let x = n * 9301 + 49297; return () => (x = (x * 9301 + 49297) % 233280) / 233280; };
  const rnd = sd(7), parts = Array.from({ length: 46 }, () => ({ a: rnd() * TAU, r: .3 + rnd() * .7, s: (rnd() - .5) * .25, z: rnd() * 1.6 + .4 }));
  const seg = (r0, r1, a0, a1) => { g.beginPath(); g.arc(0, 0, r1, a0, a1); g.arc(0, 0, r0, a1, a0, true); g.closePath(); };

  function draw(now) {
    const dt = Math.min(.05, (now - last) / 1000); last = now;
    sp += ((SPD[state] || 1) * (cfg.reduced ? .3 : 1) - sp) * Math.min(1, dt * 3); ph += dt * sp; lv += (level - lv) * .3;
    form += ((state === 'speaking' ? 1 : 0) - form) * Math.min(1, dt * (cfg.reduced ? 8 : 2.2));
    const f = form < .002 ? 0 : form > .998 ? 1 : form, E = f * f * (3 - 2 * f);       // eased morph 0 = circle, 1 = hologram
    const e = ph, col = state === 'error' ? '255,170,60' : '24,216,255', C = `rgb(${col})`;
    const tilt = E * 1.1 + Math.sin(e * .35) * .05 * E, roll = -E * .45 + Math.sin(e * .22) * .1 * E, sc = 1 - E * .2;
    const sT = Math.sin(tilt), cT = Math.cos(tilt);
    const P = h => { g.save(); g.rotate(roll); g.translate(0, -h * R * sT * sc); g.scale(sc, sc * cT); };   // enter a ring plane at height h
    const k = [0, 1, 2, 3, 4].map(i => Math.max(0, Math.min(1, power * 5 - i)));
    k.forEach((v, i) => { if (v > .05 && !pinged[i]) { pinged[i] = 1; try { onPing(i); } catch {} } });
    const I = cfg.i, boost = ((state === 'idle' ? .75 : state === 'error' ? .6 : 1) + lv * .5) * I;
    g.clearRect(0, 0, 900, 900); g.save(); g.translate(R, R); g.globalCompositeOperation = 'lighter';

    // soft glow
    P(0); const cg = g.createRadialGradient(0, 0, R * .1, 0, 0, R * .64);
    cg.addColorStop(0, 'rgba(0,0,0,0)'); cg.addColorStop(.62, `rgba(${col},${Math.min(.6, .26 * boost) * k[0]})`); cg.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = cg; g.beginPath(); g.arc(0, 0, R * .64, 0, 7); g.fill(); g.restore();

    // hologram-only depth layers behind the rings: thin "tangle" circles, spokes
    if (E > .01) {
      P(.03); g.strokeStyle = '#e8fbff'; g.lineWidth = 1;
      for (let i = 0; i < 7; i++) { const s = i % 2 ? 1 : -1; g.globalAlpha = E * .45 * k[1]; g.beginPath();
        g.arc(Math.cos(e * .3 * s + i) * R * .05, Math.sin(e * .27 * s + i * 2) * R * .05, R * (.2 + i * .055), 0, TAU); g.stroke(); }
      g.save(); g.rotate(e * .12); g.globalAlpha = E * .5 * k[1];
      for (let j = 0; j < 16; j++) { const a = j / 16 * TAU, l = j % 4 === 0 ? .6 : .46; g.beginPath(); g.moveTo(Math.cos(a) * R * .3, Math.sin(a) * R * .3); g.lineTo(Math.cos(a) * R * l, Math.sin(a) * R * l); g.stroke(); }
      g.restore(); g.restore();
    }

    // 0: bright cyan ring, drawn around as it powers up
    if (k[0] > 0) { P(0); g.rotate(-Math.PI / 2); g.shadowColor = C; g.shadowBlur = 34 * I; g.strokeStyle = C; g.globalAlpha = Math.min(1, .75 * boost);
      g.lineWidth = R * .065 * (1 + lv * .15); g.beginPath(); g.arc(0, 0, R * .5, 0, TAU * k[0]); g.stroke();
      g.shadowBlur = 8; g.strokeStyle = '#e8fbff'; g.lineWidth = 1.5; g.globalAlpha = .8;
      g.beginPath(); g.arc(0, 0, R * .54, 0, TAU * k[0]); g.stroke(); g.beginPath(); g.arc(0, 0, R * .46, 0, TAU * k[0]); g.stroke(); g.restore(); }

    // 1: hatched ring, inner dial
    if (k[1] > 0) {
      P(.05); g.globalAlpha = k[1]; g.rotate(-e * .35); g.strokeStyle = '#e8fbff'; g.shadowColor = C; g.shadowBlur = 10 * I;
      g.setLineDash([R * .011, R * .017]); g.lineWidth = R * .032; g.beginPath(); g.arc(0, 0, R * .425, 0, TAU * k[1]); g.stroke(); g.restore();
      P(.05); g.globalAlpha = .7 * k[1]; g.strokeStyle = '#e8fbff'; g.lineWidth = 1; g.beginPath(); g.arc(0, 0, R * .3, 0, TAU); g.stroke();
      for (let j = 0; j < 60; j++) { const a = j / 60 * TAU, l = j % 5 ? R * .012 : R * .028; g.beginPath(); g.moveTo(Math.cos(a) * R * .3, Math.sin(a) * R * .3); g.lineTo(Math.cos(a) * (R * .3 - l), Math.sin(a) * (R * .3 - l)); g.stroke(); }
      g.beginPath(); g.arc(0, 0, R * .1, 0, TAU); g.stroke();
      g.save(); g.rotate(e * 1.2); g.strokeStyle = C; g.lineWidth = 3; g.beginPath(); g.arc(0, 0, R * .1, 0, 1.2); g.stroke(); g.restore();
      if (E < .5 && (lv > .02 || state === 'listening')) {   // radial voice bars (circle form)
        g.strokeStyle = C; g.lineWidth = 2; g.globalAlpha = .9 * (1 - E * 2);
        for (let j = 0; j < 48; j++) { const a = j / 48 * TAU + e * .3, len = R * (.008 + lv * .06 * (.5 + .5 * Math.sin(j * 1.7 + e * 8)));
          g.beginPath(); g.moveTo(Math.cos(a) * R * .15, Math.sin(a) * R * .15); g.lineTo(Math.cos(a) * (R * .15 + len), Math.sin(a) * (R * .15 + len)); g.stroke(); }
      } else if (!titleOn && E < .3) { g.fillStyle = '#e8fbff'; g.font = `${R * .07}px "Segoe UI",sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle';
        g.fillText(String(new Date().getSeconds()).padStart(2, '0'), 0, 0); }
      g.restore(); }

    // 2: segmented button ring
    if (k[2] > 0) { P(-.06); g.rotate(e * .02); const N = 24, act = Math.floor(e * 1.6) % N;
      for (let i = 0; i < N * k[2]; i++) { const a0 = i / N * TAU + .025, a1 = (i + 1) / N * TAU - .025; seg(R * .6, R * .72, a0, a1);
        g.fillStyle = i === act ? `rgba(${col},.35)` : `rgba(${col},.05)`; g.fill(); g.strokeStyle = i === act ? '#e8fbff' : 'rgba(190,240,255,.5)'; g.lineWidth = 1; g.stroke();
        if (i % 2 === 0 && k[2] > .9 && E < .3) { g.save(); g.rotate((a0 + a1) / 2 + Math.PI / 2); g.fillStyle = 'rgba(232,251,255,.7)'; g.font = `${R * .021}px "Segoe UI",sans-serif`; g.textAlign = 'center'; g.fillText(LBL[i / 2], 0, -R * .655); g.restore(); } }
      g.restore(); }

    // 3: middle thin ring with ticks and two bright arcs
    if (k[3] > 0) { P(.1); g.globalAlpha = k[3]; g.strokeStyle = '#e8fbff'; g.lineWidth = 1; g.beginPath(); g.arc(0, 0, R * .78, 0, TAU); g.stroke();
      g.rotate(e * .05); for (let j = 0; j < 180; j++) { const a = j / 180 * TAU, l = j % 5 ? R * .01 : R * .022; g.beginPath(); g.moveTo(Math.cos(a) * R * .78, Math.sin(a) * R * .78); g.lineTo(Math.cos(a) * (R * .78 + l), Math.sin(a) * (R * .78 + l)); g.stroke(); }
      g.rotate(-e * .25); g.strokeStyle = C; g.shadowColor = C; g.shadowBlur = 12 * I; g.lineWidth = 4;
      [[.4, .9], [3.5, 1.3]].forEach(([a, l]) => { g.beginPath(); g.arc(0, 0, R * .755, a, a + l * k[3]); g.stroke(); });
      if (state === 'thinking') { g.strokeStyle = '#e8fbff'; g.lineWidth = 6; const h = e * 3; g.beginPath(); g.arc(0, 0, R * .755, h, h + .5); g.stroke(); }
      g.restore(); }

    // 4: outer broken ring, nodes, scan sweep; thick pale rim arcs in hologram form
    if (k[4] > 0) { P(-.12); g.globalAlpha = k[4]; g.rotate(-e * .04); g.strokeStyle = '#e8fbff'; g.lineWidth = 2;
      [[.2, 2.4], [2.9, 1.5], [4.6, 1.5]].forEach(([a, l]) => { g.beginPath(); g.arc(0, 0, R * .95, a, a + l * k[4]); g.stroke(); });
      g.lineWidth = 1; g.beginPath(); g.arc(0, 0, R * .985, 0, TAU * k[4]); g.stroke();
      g.strokeStyle = C; g.shadowColor = C; g.shadowBlur = 10 * I; g.lineWidth = 2;
      [0, 1.5708, 3.1416, 4.7124].forEach(a => { g.beginPath(); g.arc(Math.cos(a) * R * .95, Math.sin(a) * R * .95, R * .026, 0, TAU); g.stroke(); });
      if (E > .01) { g.rotate(e * .14); g.strokeStyle = 'rgba(150,225,255,.9)'; g.lineWidth = R * .05; g.globalAlpha = E * k[4];
        [[.5, 1.2], [2.4, 1], [4.1, 1.4]].forEach(([a, l]) => { g.beginPath(); g.arc(0, 0, R * .9, a, a + l); g.stroke(); }); }
      g.restore();
      P(-.12); g.rotate(e * (state === 'researching' ? 2.4 : .9)); const sw = g.createLinearGradient(0, 0, R * .9, 0);
      sw.addColorStop(0, `rgba(${col},0)`); sw.addColorStop(1, `rgba(${col},${(state === 'researching' ? .6 : .3) * k[4]})`);
      g.strokeStyle = sw; g.lineWidth = state === 'researching' ? 4 : 2; g.beginPath(); g.moveTo(R * .3, 0); g.lineTo(R * .9, 0); g.stroke(); g.restore();
      if (state === 'researching') { P(-.12); g.strokeStyle = C; g.lineWidth = 3; g.globalAlpha = .8; const s0 = e * 1.5; g.beginPath(); g.arc(0, 0, R * .88, s0, s0 + (Math.sin(e * 1.2) + 1.3) * 1.4); g.stroke(); g.restore(); } }

    // hologram-only: dotted orbits with a comet, and node leader lines
    if (E > .01) {
      P(-.02); g.fillStyle = '#bfefff';
      [[1.14, 0, 1], [1.04, 2.1, -1]].forEach(([rad, off, dir]) => { for (let j = 0; j < 96; j++) { const a = j / 96 * TAU + e * .12 * dir + off, vis = .5 + .5 * Math.sin(a + e * .2 + off);
        if (vis < .3) continue; g.globalAlpha = E * vis; g.beginPath(); g.arc(Math.cos(a) * R * rad, Math.sin(a) * R * rad, 1 + vis * 2.4, 0, TAU); g.fill(); } });
      for (let t = 0; t < 14; t++) { const a = e * 1.1 - t * .05; g.globalAlpha = E * (1 - t / 14); g.beginPath(); g.arc(Math.cos(a) * R * 1.14, Math.sin(a) * R * 1.14, 4.5 - t * .25, 0, TAU); g.fill(); }
      g.restore();
      g.save(); g.strokeStyle = '#e8fbff'; g.fillStyle = '#e8fbff'; g.shadowColor = C; g.shadowBlur = 8;
      [[-.92, -.3], [-.96, -.1], [-.94, .1], [-.86, .3]].forEach(([x, y], i) => { const p = .5 + .5 * Math.sin(e * 2 + i), nx = x * R, ny = y * R;
        g.globalAlpha = E * (.4 + .5 * p); g.lineWidth = 1; g.beginPath(); g.moveTo(nx, ny); g.lineTo(nx + R * .22, ny + (i - 1.5) * R * .05); g.stroke();
        g.beginPath(); g.arc(nx, ny, 3 + p * 2, 0, TAU); g.fill(); });
      g.restore();
    }

    if (!cfg.reduced && k[4] > .9) { g.fillStyle = '#e8fbff'; parts.forEach(p => { p.a += p.s * dt * sp; g.globalAlpha = .35; g.fillRect(Math.cos(p.a) * R * p.r, Math.sin(p.a) * R * p.r, p.z, p.z); }); }
    g.restore();
  }
  function frame(now) { try { g.setTransform(1, 0, 0, 1, 0, 0); draw(now); } catch (err) { console.error('orb: ' + err.message); } requestAnimationFrame(frame); }
  requestAnimationFrame(frame);
  return {
    setPower: p => { power = p; }, setState: s => { state = s; }, state: () => state, setRest: s => { rest = s; if (state === 'idle' || state === 'error') state = s; },
    toRest: () => { state = rest; }, setLevel: v => { level = v; }, onPing: f => { onPing = f; }, titleMode: b => { titleOn = b; },
    config: o => Object.assign(cfg, o), el: cv
  };
})();
