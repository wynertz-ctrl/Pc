'use strict';
/* Orb: concentric-ring HUD with idle / listening / thinking / researching / speaking / error states. */
const Orb = (() => {
  const cv = document.getElementById('cv'), g = cv.getContext('2d'), R = 450, TAU = Math.PI * 2;
  const LBL = ['AM OFF', 'GAME', 'DESK', 'AM ON', 'NEXT', 'LOCK', 'HOME', 'SYNC', 'CTRL', 'DOCS', 'COMP', 'UP'];
  const SPD = { idle: 1, listening: 1.3, thinking: 2.4, researching: 1.8, speaking: 1.5, error: 0.35 };
  let power = 0, state = 'idle', rest = 'idle', level = 0, lv = 0, ph = 0, sp = 1, last = performance.now(), titleOn = false;
  let onPing = () => {}; const cfg = { i: 1, reduced: false }; const pinged = [];
  const parts = Array.from({ length: 46 }, () => ({ a: Math.random() * TAU, r: .3 + Math.random() * .7, s: (Math.random() - .5) * .25, z: Math.random() * 1.6 + .4 }));
  const seg = (r0, r1, a0, a1) => { g.beginPath(); g.arc(0, 0, r1, a0, a1); g.arc(0, 0, r0, a1, a0, true); g.closePath(); };

  function draw(now) {
    const dt = Math.min(.05, (now - last) / 1000); last = now;
    sp += ((SPD[state] || 1) * (cfg.reduced ? .3 : 1) - sp) * Math.min(1, dt * 3); ph += dt * sp; lv += (level - lv) * .3;
    const e = ph, col = state === 'error' ? '255,170,60' : '24,216,255', C = `rgb(${col})`;
    const k = [0, 1, 2, 3, 4].map(i => Math.max(0, Math.min(1, power * 5 - i)));
    k.forEach((v, i) => { if (v > .05 && !pinged[i]) { pinged[i] = 1; try { onPing(i); } catch {} } });
    const I = cfg.i, boost = ((state === 'idle' ? .75 : state === 'error' ? .6 : 1) + lv * .5) * I;
    g.clearRect(0, 0, 900, 900); g.save(); g.translate(R, R); g.globalCompositeOperation = 'lighter';

    const cg = g.createRadialGradient(0, 0, R * .1, 0, 0, R * .64);
    cg.addColorStop(0, 'rgba(0,0,0,0)'); cg.addColorStop(.62, `rgba(${col},${Math.min(.6, .26 * boost) * k[0]})`); cg.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = cg; g.beginPath(); g.arc(0, 0, R * .64, 0, 7); g.fill();

    if (k[0] > 0) { g.save(); g.rotate(-Math.PI / 2); g.shadowColor = C; g.shadowBlur = 34 * I; g.strokeStyle = C; g.globalAlpha = Math.min(1, .75 * boost);
      g.lineWidth = R * .065; g.beginPath(); g.arc(0, 0, R * .5, 0, TAU * k[0]); g.stroke();
      g.shadowBlur = 8; g.strokeStyle = '#e8fbff'; g.lineWidth = 1.5; g.globalAlpha = .8;
      g.beginPath(); g.arc(0, 0, R * .54, 0, TAU * k[0]); g.stroke(); g.beginPath(); g.arc(0, 0, R * .46, 0, TAU * k[0]); g.stroke(); g.restore(); }

    if (k[1] > 0) {
      g.save(); g.globalAlpha = k[1]; g.rotate(-e * .35); g.strokeStyle = '#e8fbff'; g.shadowColor = C; g.shadowBlur = 10 * I;
      g.setLineDash([R * .011, R * .017]); g.lineWidth = R * .032; g.beginPath(); g.arc(0, 0, R * .425, 0, TAU * k[1]); g.stroke(); g.restore();
      g.save(); g.globalAlpha = .7 * k[1]; g.strokeStyle = '#e8fbff'; g.lineWidth = 1; g.beginPath(); g.arc(0, 0, R * .3, 0, TAU); g.stroke();
      for (let j = 0; j < 60; j++) { const a = j / 60 * TAU, l = j % 5 ? R * .012 : R * .028; g.beginPath(); g.moveTo(Math.cos(a) * R * .3, Math.sin(a) * R * .3); g.lineTo(Math.cos(a) * (R * .3 - l), Math.sin(a) * (R * .3 - l)); g.stroke(); }
      g.beginPath(); g.arc(0, 0, R * .1, 0, TAU); g.stroke();
      g.save(); g.rotate(e * 1.2); g.strokeStyle = C; g.lineWidth = 3; g.beginPath(); g.arc(0, 0, R * .1, 0, 1.2); g.stroke(); g.restore();
      if (lv > .02 || state === 'listening' || state === 'speaking') {   // radial voice bars
        g.strokeStyle = C; g.lineWidth = 2; g.globalAlpha = .9;
        for (let j = 0; j < 48; j++) { const a = j / 48 * TAU + e * .3, len = R * (.008 + lv * .06 * (.5 + .5 * Math.sin(j * 1.7 + e * 8)));
          g.beginPath(); g.moveTo(Math.cos(a) * R * .15, Math.sin(a) * R * .15); g.lineTo(Math.cos(a) * (R * .15 + len), Math.sin(a) * (R * .15 + len)); g.stroke(); }
      } else if (!titleOn) { g.fillStyle = '#e8fbff'; g.font = `${R * .07}px "Segoe UI",sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle';
        g.fillText(String(new Date().getSeconds()).padStart(2, '0'), 0, 0); }
      g.restore(); }

    if (k[2] > 0) { g.save(); g.rotate(e * .02); const N = 24, act = Math.floor(e * 1.6) % N;
      for (let i = 0; i < N * k[2]; i++) { const a0 = i / N * TAU + .025, a1 = (i + 1) / N * TAU - .025; seg(R * .6, R * .72, a0, a1);
        g.fillStyle = i === act ? `rgba(${col},.35)` : `rgba(${col},.05)`; g.fill(); g.strokeStyle = i === act ? '#e8fbff' : 'rgba(190,240,255,.5)'; g.lineWidth = 1; g.stroke();
        if (i % 2 === 0 && k[2] > .9) { g.save(); g.rotate((a0 + a1) / 2 + Math.PI / 2); g.fillStyle = 'rgba(232,251,255,.7)'; g.font = `${R * .021}px "Segoe UI",sans-serif`; g.textAlign = 'center'; g.fillText(LBL[i / 2], 0, -R * .655); g.restore(); } }
      g.restore(); }

    if (k[3] > 0) { g.save(); g.globalAlpha = k[3]; g.strokeStyle = '#e8fbff'; g.lineWidth = 1; g.beginPath(); g.arc(0, 0, R * .78, 0, TAU); g.stroke();
      g.rotate(e * .05); for (let j = 0; j < 180; j++) { const a = j / 180 * TAU, l = j % 5 ? R * .01 : R * .022; g.beginPath(); g.moveTo(Math.cos(a) * R * .78, Math.sin(a) * R * .78); g.lineTo(Math.cos(a) * (R * .78 + l), Math.sin(a) * (R * .78 + l)); g.stroke(); }
      g.rotate(-e * .25); g.strokeStyle = C; g.shadowColor = C; g.shadowBlur = 12 * I; g.lineWidth = 4;
      [[.4, .9], [3.5, 1.3]].forEach(([a, l]) => { g.beginPath(); g.arc(0, 0, R * .755, a, a + l * k[3]); g.stroke(); });
      if (state === 'thinking') { g.strokeStyle = '#e8fbff'; g.lineWidth = 6; const h = e * 3; g.beginPath(); g.arc(0, 0, R * .755, h, h + .5); g.stroke(); }
      g.restore(); }

    if (k[4] > 0) { g.save(); g.globalAlpha = k[4]; g.rotate(-e * .04); g.strokeStyle = '#e8fbff'; g.lineWidth = 2;
      [[.2, 2.4], [2.9, 1.5], [4.6, 1.5]].forEach(([a, l]) => { g.beginPath(); g.arc(0, 0, R * .95, a, a + l * k[4]); g.stroke(); });
      g.lineWidth = 1; g.beginPath(); g.arc(0, 0, R * .985, 0, TAU * k[4]); g.stroke();
      g.strokeStyle = C; g.shadowColor = C; g.shadowBlur = 10 * I; g.lineWidth = 2;
      [0, 1.5708, 3.1416, 4.7124].forEach(a => { g.beginPath(); g.arc(Math.cos(a) * R * .95, Math.sin(a) * R * .95, R * .026, 0, TAU); g.stroke(); }); g.restore();
      const scanSp = state === 'researching' ? 2.4 : .9; g.save(); g.rotate(e * scanSp); const sw = g.createLinearGradient(0, 0, R * .9, 0);
      sw.addColorStop(0, `rgba(${col},0)`); sw.addColorStop(1, `rgba(${col},${(state === 'researching' ? .6 : .3) * k[4]})`);
      g.strokeStyle = sw; g.lineWidth = state === 'researching' ? 4 : 2; g.beginPath(); g.moveTo(R * .3, 0); g.lineTo(R * .9, 0); g.stroke(); g.restore();
      if (state === 'researching') { g.save(); g.strokeStyle = C; g.lineWidth = 3; g.globalAlpha = .8; const s0 = e * 1.5; g.beginPath(); g.arc(0, 0, R * .88, s0, s0 + (Math.sin(e * 1.2) + 1.3) * 1.4); g.stroke(); g.restore(); } }

    if (!cfg.reduced && k[4] > .9) { g.fillStyle = '#e8fbff'; parts.forEach(p => { p.a += p.s * dt * sp; g.globalAlpha = .35; g.fillRect(Math.cos(p.a) * R * p.r, Math.sin(p.a) * R * p.r, p.z, p.z); }); }
    g.restore();
  }
  function frame(now) { try { g.setTransform(1, 0, 0, 1, 0, 0); draw(now); } catch (err) { console.error('orb: ' + err.message); } requestAnimationFrame(frame); }
  requestAnimationFrame(frame);
  return {
    setPower: p => { power = p; }, setState: s => { state = s; }, state: () => state, setRest: s => { rest = s; if (state === 'idle' || state === 'error') state = s; },
    toRest: () => { state = rest; }, setLevel: v => { level = v; }, onPing: f => { onPing = f; }, titleMode: b => { titleOn = b; },
    config: o => Object.assign(cfg, o), el: cv
  };
})();
