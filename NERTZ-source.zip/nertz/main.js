'use strict';
const { app, BrowserWindow, ipcMain, shell, safeStorage, session, dialog, Menu } = require('electron');
const path = require('path'), fs = require('fs'), { spawn } = require('child_process');

if (!app.requestSingleInstanceLock()) app.quit();
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

let win;
const P = f => path.join(app.getPath('userData'), f);
const log = m => { try { fs.mkdirSync(app.getPath('userData'), { recursive: true }); fs.appendFileSync(P('nertz.log'), new Date().toISOString() + ' ' + m + '\n'); } catch {} };
/* Compatibility mode = software rendering. Default on 32-bit systems; also switched on automatically after a GPU crash. */
if (process.arch === 'ia32' || fs.existsSync(P('nogpu'))) app.disableHardwareAcceleration();
const compatRestart = () => { try { fs.writeFileSync(P('nogpu'), '1'); } catch {} app.relaunch(); app.exit(0); };
const rd = (f, d) => { try { return JSON.parse(fs.readFileSync(P(f), 'utf8')); } catch { return d; } };
const wr = (f, v) => { fs.mkdirSync(app.getPath('userData'), { recursive: true }); fs.writeFileSync(P(f), JSON.stringify(v)); };

const DEF = { provider: 'gemini', model: '', sttModel: '', baseUrl: '', searchProvider: 'tavily', voice: '', voiceVolume: 1,
  startupSound: true, startupVolume: 0.6, reducedMotion: false, intensity: 1, mic: '', memoryOn: true, userName: 'sir' };
const settings = () => ({ ...DEF, ...rd('settings.json', {}) });

/* ---- secrets: encrypted with Windows DPAPI via safeStorage, never sent to the UI ---- */
function keys() {
  try { return fs.existsSync(P('keys.bin')) ? JSON.parse(safeStorage.decryptString(fs.readFileSync(P('keys.bin')))) : {}; }
  catch { return {}; }
}
function saveKeys(k) {
  if (!safeStorage.isEncryptionAvailable()) throw new Error('Secure key storage is not available on this system.');
  fs.mkdirSync(app.getPath('userData'), { recursive: true });
  fs.writeFileSync(P('keys.bin'), safeStorage.encryptString(JSON.stringify(k)));
}

/* ---- helpers ---- */
async function http(url, opt = {}, ms = 60000) {
  let r;
  try { r = await fetch(url, { ...opt, signal: opt.signal ? AbortSignal.any([opt.signal, AbortSignal.timeout(ms)]) : AbortSignal.timeout(ms) }); }
  catch (e) { if (opt.signal?.aborted) throw new Error('Cancelled.'); throw new Error(e.name === 'TimeoutError' ? 'The request timed out.' : 'Could not reach the service. Check the internet connection.'); }
  if (!r.ok) {
    let t = ''; try { t = (await r.text()).slice(0, 200); } catch {}
    throw new Error(r.status === 401 || r.status === 403 ? `The API key was rejected (${r.status}).`
      : r.status === 429 ? 'Rate limit or quota reached (429). A paid plan or more credit may be needed.'
      : `Service error ${r.status}. ${t}`);
  }
  return r;
}
const h = (ch, fn) => ipcMain.handle(ch, async (e, a) => {
  try { return { ok: true, ...(await fn(a || {}, e)) }; } catch (err) { return { ok: false, error: err.message || String(err) }; }
});
const baseOf = st => (st.baseUrl || 'https://api.openai.com/v1').replace(/\/$/, '');
const isLocal = st => st.provider === 'custom' && /localhost|127\.0\.0\.1/.test(st.baseUrl || '');

const GEM = 'https://generativelanguage.googleapis.com/v1beta';
const gemModel = st => st.model || 'gemini-3.8-flash';
async function gemCall(key, st, body, ms = 90000) {
  const go = async b => (await http(`${GEM}/models/${encodeURIComponent(gemModel(st))}:generateContent`, { method: 'POST',
    headers: { 'content-type': 'application/json', 'x-goog-api-key': key }, body: JSON.stringify(b) }, ms)).json();
  let j;
  try { j = await go(body); }
  catch (e) {   // if this model rejects the thinking setting, retry once without it
    if (/Service error 400/.test(e.message) && body.generationConfig?.thinkingConfig) {
      const b2 = { ...body, generationConfig: { ...body.generationConfig } }; delete b2.generationConfig.thinkingConfig; j = await go(b2);
    } else throw e;
  }
  if (j.promptFeedback?.blockReason) throw new Error('Gemini blocked that request (' + j.promptFeedback.blockReason + ').');
  const cand = j.candidates?.[0], text = (cand?.content?.parts || []).filter(p => !p.thought).map(p => p.text || '').join('');
  if (!text && cand?.finishReason && cand.finishReason !== 'STOP') throw new Error('Gemini returned no text (' + cand.finishReason + ').');
  const seen = new Set(), sources = [];
  (cand?.groundingMetadata?.groundingChunks || []).forEach(c => { const u = c.web?.uri; if (u && !seen.has(u)) { seen.add(u); sources.push({ title: c.web.title || u, url: u, snippet: '', date: '' }); } });
  return { text, sources };
}
async function validateAi(prov, key, st) {
  if (prov === 'gemini') { await http(`${GEM}/models?pageSize=1`, { headers: { 'x-goog-api-key': key } }, 15000); return; }
  if (prov === 'anthropic') await http('https://api.anthropic.com/v1/models', { headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01' } }, 15000);
  else await http(baseOf({ ...st, baseUrl: st.baseUrl }) + '/models', { headers: { Authorization: 'Bearer ' + key } }, 15000);
}
async function runSearch(prov, key, q) {
  if (prov === 'brave') {
    const r = await http('https://api.search.brave.com/res/v1/web/search?count=8&q=' + encodeURIComponent(q), { headers: { 'X-Subscription-Token': key, Accept: 'application/json' } }, 20000);
    const j = await r.json();
    return (j.web?.results || []).map(x => ({ title: x.title, url: x.url, snippet: (x.description || '').replace(/<[^>]+>/g, ''), date: x.age || '' }));
  }
  const r = await http('https://api.tavily.com/search', { method: 'POST', headers: { 'content-type': 'application/json', Authorization: 'Bearer ' + key },
    body: JSON.stringify({ query: q, max_results: 8 }) }, 25000);
  const j = await r.json();
  return (j.results || []).map(x => ({ title: x.title, url: x.url, snippet: x.content || '', date: x.published_date || '' }));
}

/* ---- IPC ---- */
h('settings:get', async () => ({ settings: settings(), hasAiKey: !!keys().ai, hasSearchKey: !!keys().search }));
h('settings:set', async p => { wr('settings.json', { ...settings(), ...p }); return {}; });
h('key:save', async ({ kind, value }) => {
  value = String(value || '').trim(); if (!value) throw new Error('Paste a key first.');
  const st = settings(), k = keys();
  if (kind === 'ai') {
    let prov = st.provider;
    if (value.startsWith('sk-ant-')) prov = 'anthropic'; else if (value.startsWith('AIza')) prov = 'gemini'; else if (prov === 'anthropic') prov = 'openai';
    await validateAi(prov, value, st); k.ai = value; saveKeys(k); wr('settings.json', { ...st, provider: prov });
    return { provider: prov };
  }
  await runSearch(st.searchProvider, value, 'test'); k.search = value; saveKeys(k); return {};
});
h('key:clear', async ({ kind }) => { const k = keys(); delete k[kind === 'ai' ? 'ai' : 'search']; saveKeys(k); return {}; });
h('status', async () => {
  let internet = false;
  try { await fetch('https://www.gstatic.com/generate_204', { signal: AbortSignal.timeout(4000) }); internet = true; } catch {}
  const st = settings(), k = keys(), local = isLocal(st);
  return { internet, local, aiConfigured: local || (st.provider === 'custom' ? !!st.baseUrl : !!k.ai),
    searchConfigured: (st.provider === 'gemini' && !!k.ai) || (st.searchProvider !== 'none' && !!k.search) };
});
h('ai:chat', async ({ system, messages, search, fast }) => {
  const st = settings(), k = keys().ai || '';
  if (st.provider !== 'custom' && !k) throw new Error('No API key is set. Open settings with Control comma.');
  const parse = d => { const m = /^data:([^;]+);base64,(.+)$/.exec(d); return { mt: m[1], b: m[2] }; };
  if (st.provider === 'gemini') {
    const contents = messages.map(m => ({ role: m.role === 'assistant' ? 'model' : 'user',
      parts: [...(m.images || []).map(d => { const p = parse(d); return { inlineData: { mimeType: p.mt, data: p.b } }; }), { text: m.content }] }));
    const body = { systemInstruction: { parts: [{ text: system }] }, contents, generationConfig: { thinkingConfig: { thinkingLevel: fast ? 'minimal' : 'low' } } };
    if (search) body.tools = [{ google_search: {} }];   // Gemini's built-in Google Search grounding: no separate search key needed
    return await gemCall(k, st, body, 120000);
  }
  if (st.provider === 'anthropic') {
    const msgs = messages.map(m => ({ role: m.role, content: m.images?.length
      ? [...m.images.map(d => { const p = parse(d); return { type: 'image', source: { type: 'base64', media_type: p.mt, data: p.b } }; }), { type: 'text', text: m.content }]
      : m.content }));
    const r = await http('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': k, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: st.model || 'claude-sonnet-5-5', max_tokens: 2000, system, messages: msgs }) });
    return { text: ((await r.json()).content || []).map(c => c.text || '').join('') };
  }
  const msgs = [{ role: 'system', content: system }, ...messages.map(m => ({ role: m.role, content: m.images?.length
    ? [{ type: 'text', text: m.content }, ...m.images.map(d => ({ type: 'image_url', image_url: { url: d } }))] : m.content }))];
  const r = await http(baseOf(st) + '/chat/completions', { method: 'POST', headers: { 'content-type': 'application/json', ...(k ? { Authorization: 'Bearer ' + k } : {}) },
    body: JSON.stringify({ model: st.model || 'gpt-4o-mini', messages: msgs }) }, 120000);
  return { text: (await r.json()).choices?.[0]?.message?.content || '' };
});
/* Streaming chat (Gemini): text is pushed to the window as it is generated, so speech can start after the first sentence. */
const ctls = new Map();
h('ai:abort', async ({ id }) => { ctls.get(id)?.abort(); ctls.delete(id); return {}; });
h('ai:stream', async ({ id, system, messages, search }, e) => {
  const st = settings(), k = keys().ai || '', ctl = new AbortController(); ctls.set(id, ctl);
  try {
    if (st.provider !== 'gemini') throw new Error('Streaming is only available with Gemini.');
    if (!k) throw new Error('No API key is set. Open settings with Control comma.');
    const parse = d => { const m = /^data:([^;]+);base64,(.+)$/.exec(d); return { mt: m[1], b: m[2] }; };
    const contents = messages.map(m => ({ role: m.role === 'assistant' ? 'model' : 'user',
      parts: [...(m.images || []).map(d => { const p = parse(d); return { inlineData: { mimeType: p.mt, data: p.b } }; }), { text: m.content }] }));
    const body = { systemInstruction: { parts: [{ text: system }] }, contents, generationConfig: { thinkingConfig: { thinkingLevel: 'minimal' } } };
    if (search) body.tools = [{ google_search: {} }];
    const open = b => http(`${GEM}/models/${encodeURIComponent(gemModel(st))}:streamGenerateContent?alt=sse`, { method: 'POST',
      headers: { 'content-type': 'application/json', 'x-goog-api-key': k }, body: JSON.stringify(b), signal: ctl.signal }, 90000);
    let r; try { r = await open(body); } catch (err) { if (/Service error 400/.test(err.message)) { delete body.generationConfig.thinkingConfig; r = await open(body); } else throw err; }
    const reader = r.body.getReader(), dec = new TextDecoder(), seen = new Set(), sources = []; let buf = '', text = '';
    for (;;) {
      const { done, value } = await reader.read(); if (done) break; buf += dec.decode(value, { stream: true });
      let i; while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1); if (!line.startsWith('data:')) continue;
        let j; try { j = JSON.parse(line.slice(5)); } catch { continue; }
        if (j.promptFeedback?.blockReason) throw new Error('Gemini blocked that request (' + j.promptFeedback.blockReason + ').');
        const cand = j.candidates?.[0], t = (cand?.content?.parts || []).filter(p => !p.thought).map(p => p.text || '').join('');
        if (t) { text += t; e.sender.send('ai:chunk', { id, text: t }); }
        (cand?.groundingMetadata?.groundingChunks || []).forEach(c => { const u = c.web?.uri; if (u && !seen.has(u)) { seen.add(u); sources.push({ title: c.web.title || u, url: u, snippet: '', date: '' }); } });
      }
    }
    if (!text) throw new Error('Gemini returned no text.');
    return { text, sources };
  } finally { ctls.delete(id); }
});
h('search:web', async ({ q }) => {
  const st = settings(), k = keys().search;
  if (st.searchProvider === 'none' || !k) throw new Error('Web search is not configured.');
  return { results: await runSearch(st.searchProvider, k, q) };
});
h('stt', async ({ b64, mime }) => {
  const st = settings(), k = keys().ai || '';
  if (st.provider === 'gemini') {
    if (!k) throw new Error('No API key is set. Open settings with Control comma.');
    const body = { contents: [{ role: 'user', parts: [{ inlineData: { mimeType: mime, data: b64 } },
      { text: 'Transcribe this audio exactly as spoken, in the language spoken (English unless clearly otherwise). Output only the transcript, with no commentary. If there is no intelligible speech, output nothing. Names that may appear: NERTZ, Gemini, Claude.' }] }],
      generationConfig: { thinkingConfig: { thinkingLevel: 'minimal' } } };
    const fast = { ...st, model: st.sttModel || 'gemini-3.1-flash-lite' };   // a small, fast model is quicker and plenty for transcription
    let out;
    try { out = await gemCall(k, fast, body, 20000); }
    catch (e) { if (/Service error 404|not found/i.test(e.message) && !st.sttModel) out = await gemCall(k, st, body, 25000); else throw e; }
    return { text: out.text.trim() };
  }
  if (st.provider === 'anthropic') throw new Error('Voice input needs an OpenAI-compatible provider. Anthropic offers no speech-to-text.');
  const fd = new FormData(); fd.append('model', 'whisper-1');
  fd.append('file', new Blob([Buffer.from(b64, 'base64')], { type: mime }), 'audio.webm');
  const r = await http(baseOf(st) + '/audio/transcriptions', { method: 'POST', headers: k ? { Authorization: 'Bearer ' + k } : {}, body: fd }, 40000);
  return { text: (await r.json()).text || '' };
});
h('ext:open', async ({ url }) => {
  const u = new URL(url); if (!/^https?:$/.test(u.protocol)) throw new Error('Only web links can be opened.');
  await shell.openExternal(u.href); return {};
});
const APPS = { notepad: 'notepad.exe', calculator: 'calc.exe', calc: 'calc.exe', paint: 'mspaint.exe', explorer: 'explorer.exe', 'file explorer': 'explorer.exe' };
h('sys:open', async ({ name }) => {
  const exe = APPS[String(name).toLowerCase()];
  if (!exe) throw new Error('I can only open notepad, calculator, paint and file explorer.');
  const c = await dialog.showMessageBox(win, { type: 'question', buttons: ['Open', 'Cancel'], defaultId: 0, cancelId: 1, message: `NERTZ wants to open ${name}.` });
  if (c.response !== 0) return { done: false };
  await new Promise((res, rej) => { const p = spawn(exe, [], { detached: true, stdio: 'ignore' }); p.once('error', rej); p.once('spawn', () => { p.unref(); res(); }); });
  return { done: true };
});
h('img:pick', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp'] }] });
  if (r.canceled) return { canceled: true };
  const f = r.filePaths[0]; if (fs.statSync(f).size > 25e6) throw new Error('That image is larger than 25 MB.');
  const ext = path.extname(f).slice(1).toLowerCase();
  return { dataUrl: `data:image/${ext === 'jpg' ? 'jpeg' : ext};base64,` + fs.readFileSync(f).toString('base64'), name: path.basename(f) };
});
h('hist:get', async () => ({ m: rd('history.json', []) }));
h('hist:set', async ({ m }) => { wr('history.json', (m || []).slice(-200)); return {}; });
h('hist:clear', async () => { wr('history.json', []); return {}; });
h('mem:get', async () => ({ l: rd('memory.json', []) }));
h('mem:set', async ({ l }) => { wr('memory.json', (l || []).slice(0, 100)); return {}; });
h('app:info', async () => ({ version: app.getVersion(), electron: process.versions.electron, chrome: process.versions.chrome, arch: process.arch, os: process.platform + ' ' + process.getSystemVersion() }));
h('app:fs', async () => { win.setFullScreen(!win.isFullScreen()); return {}; });
let alive = false;
h('ui:alive', async () => { alive = true; return {}; });
h('app:quit', async () => { app.quit(); return {}; });

/* ---- window ---- */
function create() {
  win = new BrowserWindow({ show: false, fullscreen: true, backgroundColor: '#000000', autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
  Menu.setApplicationMenu(null);
  win.once('ready-to-show', () => win.show());
  win.webContents.on('console-message', (_e, level, msg, line, src) => { if (level >= 2) log(`renderer ${level === 3 ? 'error' : 'warning'}: ${msg} (${path.basename(src || '')}:${line})`); });
  win.webContents.on('did-fail-load', (_e, code, desc) => log('load failed ' + code + ' ' + desc));
  win.webContents.on('render-process-gone', (_e, d) => { log('renderer gone: ' + d.reason); if (!fs.existsSync(P('nogpu'))) compatRestart(); });
  setTimeout(async () => {
    if (alive || !win || win.isDestroyed()) return; log('watchdog: interface did not start');
    const r = await dialog.showMessageBox(win, { type: 'warning', buttons: ['Restart in compatibility mode', 'Open log folder', 'Quit'], defaultId: 0, cancelId: 2,
      message: 'NERTZ did not start properly.', detail: 'A log was saved to ' + P('nertz.log') });
    if (r.response === 0) compatRestart(); else if (r.response === 1) shell.openPath(app.getPath('userData')); else app.quit();
  }, 12000);
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', e => e.preventDefault());
  win.webContents.on('before-input-event', (e, i) => {
    if (i.type !== 'keyDown') return;
    if (i.key === 'F11') { win.setFullScreen(!win.isFullScreen()); e.preventDefault(); }
    else if (i.key === 'F12' || (i.control && i.shift && i.key.toLowerCase() === 'i')) win.webContents.toggleDevTools();
    else if (i.control && i.shift && i.key.toLowerCase() === 'g') { // toggle compatibility mode (software rendering) and restart
      if (fs.existsSync(P('nogpu'))) { try { fs.unlinkSync(P('nogpu')); } catch {} app.relaunch(); app.exit(0); } else compatRestart(); }
  });
}
app.whenReady().then(() => {
  session.defaultSession.setPermissionRequestHandler((_w, perm, cb, d) => cb(perm === 'media' && String(d.requestingUrl).startsWith('file://')));
  session.defaultSession.setPermissionCheckHandler((_w, perm) => perm === 'media');
  create();
});
app.on('child-process-gone', (_e, d) => { log('child gone: ' + d.type + ' ' + d.reason); if (d.type === 'GPU' && !fs.existsSync(P('nogpu'))) compatRestart(); });
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('window-all-closed', () => app.quit());
