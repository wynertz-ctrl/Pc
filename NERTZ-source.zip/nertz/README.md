# NERTZ AI – Windows desktop assistant (32-bit and 64-bit)

One code base builds a **combined installer that works on 32-bit and 64-bit Windows**, as an installer.

## Build on GitHub (no tools needed on your PC)
1. Create a GitHub repository and upload everything in this folder (keep `.github/workflows/build.yml`).
2. Open the **Actions** tab, choose **Build NERTZ**, press **Run workflow** (it also runs on every push).
3. When it finishes, open the run and download the **NERTZ-windows** artifact. For a permanent download page, push a tag such as `v1.0.4` and the files are attached to a GitHub Release.

Output: `NERTZ-Setup-1.0.4.exe`, a single installer for 32-bit and 64-bit Windows (installs to Program Files-style folder, adds Start Menu and desktop shortcuts, and an uninstaller).

## Run locally
`npm install` then `npm start`. Build locally with `npm run dist`.

## First use
Press **Ctrl+,** (or the SETTINGS button): paste an AI key (Google Gemini, OpenAI or Anthropic; the key type is detected). Gemini uses model `gemini-3.8-flash` by default, optionally a Tavily or Brave search key. For an offline model choose *Custom* and set a base URL such as `http://localhost:11434/v1`.

Keys: type and press Enter · **M** microphone · **Esc** stop / close review · **F11** fullscreen · **Ctrl+Q** quit.
Say "review <subject>" to open the review workspace; "remember that …", "open notepad", "new conversation".

## Notes
- Requires Windows 10 or later (Electron 33). Windows 7/8 would need an older Electron.
- The app is unsigned, so Windows SmartScreen may warn; choose More info, then Run anyway.
- Add `build/icon.ico` (256x256) for a custom icon.
- Voice input is transcribed by Gemini (or Whisper with an OpenAI key) and needs internet. Voice output works offline using Windows voices.
- Without a search key, reviews use built-in knowledge, say so, and show no sources.

## If the screen is black
- Press **Ctrl+Shift+G** to switch compatibility mode (software rendering) on or off; the app restarts. It also switches on automatically after a graphics crash, and by default on 32-bit Windows.
- A log is written to `%APPDATA%\NERTZ\nertz.log`. **F12** opens developer tools.
- If the interface fails to start within 12 seconds, a dialog offers to restart in compatibility mode.
